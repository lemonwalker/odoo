# -*- coding: utf-8 -*-

from . import account_account_template
from . import account_account
from . import account_tax_group
from . import account_chart_template
from . import account_journal
from . import res_currency




